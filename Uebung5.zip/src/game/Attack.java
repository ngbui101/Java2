package game;

import fiend.*;
import hero.*;

public interface Attack {

    void attack(GameObject f);

}
