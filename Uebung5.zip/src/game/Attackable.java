package game;

import fiend.*;
import hero.*;

public interface Attackable {
    void sustainDamage(int damage);
}
